-- stage expand_unique (expand)
CREATE UNIQUE INDEX NOT VALID idx_account_user_last_name_unique ON account_user (last_name);
-- stage validate_unique (contract)
ALTER INDEX idx_account_user_last_name_unique VALIDATE;
