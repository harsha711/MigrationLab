BEGIN;
--
-- Alter field last_name on user
--
ALTER TABLE "account_user" ADD CONSTRAINT "account_user_last_name_ce914771_uniq" UNIQUE ("last_name");
CREATE INDEX "account_user_last_name_ce914771_like" ON "account_user" ("last_name" varchar_pattern_ops);
COMMIT;
