-- stage expand_unique (expand)
CREATE UNIQUE INDEX idx_account_user_last_name_unique ON account_user (last_name) WHERE last_name IS NOT NULL;
-- stage validate_unique (contract)
ALTER INDEX idx_account_user_last_name_unique VALIDATE;
