-- stage expand_01 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
CREATE OR REPLACE FUNCTION sync_note_customer() RETURNS TRIGGER AS $$ BEGIN IF TG_OP = 'UPDATE' THEN IF NEW.note IS DISTINCT FROM OLD.note THEN NEW.customer_note := NEW.note; END IF; IF NEW.customer_note IS DISTINCT FROM OLD.customer_date THEN NEW.note := NEW.customer_note; END IF; ELSIF TG_OP = 'INSERT' THEN IF NEW.note IS NOT NULL THEN NEW.customer_note := NEW.note; ELSIF NEW.customer_note IS NOT NULL THEN NEW.note := NEW.customer_note; END IF; END IF; RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_trig AFTER INSERT OR UPDATE ON account_user EXECUTE FUNCTION sync_note_customer();
-- stage backfill_01 (backfill)
UPDATE account_user SET customer_note = note;
-- stage contract_01 (contract)
DROP TRIGGER sync_note_trig ON account_user;
ALTER TABLE account_user DROP COLUMN note;
