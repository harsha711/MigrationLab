BEGIN;
--
-- Alter field note on user
--
-- (no-op)
--
-- Rename field note on user to customer_note
--
-- (no-op)
COMMIT;
