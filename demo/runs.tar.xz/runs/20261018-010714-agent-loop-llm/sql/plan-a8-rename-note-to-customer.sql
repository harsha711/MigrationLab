-- stage expand_rename (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
-- stage sync_expand (expand)
UPDATE account_user SET customer_note = note;
-- stage create_trigger (expand)
CREATE OR REPLACE FUNCTION sync_note_columns() RETURNS trigger AS $$ BEGIN IF TG_OP = 'INSERT' THEN IF NEW.note IS NOT NULL AND NEW.customer_note IS NULL THEN NEW.customer_note := NEW.note; ELSIF NEW.customer_note IS NOT NULL AND NEW.note IS NULL THEN NEW.note := NEW.customer_note; END IF; ELSIF TG_OP = 'UPDATE' THEN IF NEW.note != OLD.note THEN NEW.customer_note := NEW.note; ELSIF NEW.customer_note != OLD.customer_note THEN NEW.note := NEW.customer_note; END IF; END IF; RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER note_sync_trigger BEFORE INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_columns();
-- stage backfill_after_deploy (backfill)
UPDATE account_user SET note = customer_note;
-- stage contract_drop_note (contract)
DROP TRIGGER IF EXISTS note_sync_trigger ON account_user;
ALTER TABLE account_user DROP COLUMN note;
