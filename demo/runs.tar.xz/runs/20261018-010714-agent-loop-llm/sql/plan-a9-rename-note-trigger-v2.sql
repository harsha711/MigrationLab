-- stage expand_note_col (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
UPDATE account_user SET customer_note = note;
CREATE OR REPLACE FUNCTION sync_note_customer_note_trigger() RETURNS trigger AS $$ BEGIN IF TG_OP = 'INSERT' THEN IF NEW.note IS NOT NULL THEN NEW.customer_note := NEW.note; ELSIF NEW.customer_note IS NOT NULL THEN NEW.note := NEW.customer_note; END IF; ELSIF TG_OP = 'UPDATE' THEN IF NEW.note != OLD.note THEN NEW.customer_note := NEW.note; END IF; IF NEW.customer_note != OLD.customer_note THEN NEW.note := NEW.customer_note; END IF; END IF; RETURN NEW; END;$$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_customer_note_insert AFTER INSERT ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note_trigger();
CREATE TRIGGER sync_note_customer_note_update AFTER UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note_update();
-- stage backfill_sync_note (backfill)
UPDATE account_user SET note = customer_note;
-- stage contract_drop_note (contract)
DROP TRIGGER sync_note_customer_note_insert ON account_user;
DROP TRIGGER sync_note_customer_note_update ON account_user;
ALTER TABLE account_user DROP COLUMN note;
