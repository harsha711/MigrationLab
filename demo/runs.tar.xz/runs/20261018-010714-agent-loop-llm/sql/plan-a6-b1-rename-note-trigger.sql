-- stage expand_note_col (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
UPDATE account_user SET customer_note = note;
CREATE OR REPLACE FUNCTION sync_note_customer_note() RETURNS trigger AS $$ BEGIN IF TG_OP = 'UPDATE' THEN IF NEW.note != OLD.note THEN NEW.customer_note := NEW.note; ELSIF NEW.customer_note != OLD.customer_note THEN NEW.note := NEW.customer_note; END IF; END IF; RETURN NEW; END;$$ LANGUAGE plpgsql;
CREATE TRIGGER note_sync_trigger AFTER UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note();
-- stage backfill_sync_note (backfill)
UPDATE account_user SET note = customer_note;
-- stage contract_drop_note (contract)
DROP TRIGGER note_sync_trigger ON account_user;
ALTER TABLE account_user DROP COLUMN note;
