-- stage expand_rename (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
-- stage sync_expand (expand)
UPDATE account_user SET customer_note = note;
-- stage backfill_after_deploy (backfill)
UPDATE account_user SET note = customer_note;
-- stage contract_drop_note (contract)
ALTER TABLE account_user DROP COLUMN note;
