-- stage expand_rename (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
UPDATE account_user SET customer_note = note;
-- stage backfill_ensure (backfill)
UPDATE account_user SET customer_note = note;
-- stage contract_drop_note (contract)
ALTER TABLE account_user DROP COLUMN note;
