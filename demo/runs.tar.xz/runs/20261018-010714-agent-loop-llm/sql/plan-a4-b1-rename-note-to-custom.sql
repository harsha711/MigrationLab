-- stage expand (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
UPDATE account_user SET customer_note = note;
CREATE OR REPLACE FUNCTION sync_note_columns() RETURNS TRIGGER AS $$ BEGIN IF TG_OP = 'INSERT' THEN NEW.customer_note := NEW.note; NEW.note := NEW.customer_note; ELSIF TG_OP = 'UPDATE' THEN NEW.customer_note := NEW.note; NEW.note := NEW.customer_note; END IF; RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_trigger BEFORE INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_columns();
-- stage backfill (backfill)
UPDATE account_user SET note = customer_note, customer_note = note;
-- stage contract (contract)
DROP TRIGGER IF EXISTS sync_note_trigger ON account_user;
ALTER TABLE account_user DROP COLUMN note;
