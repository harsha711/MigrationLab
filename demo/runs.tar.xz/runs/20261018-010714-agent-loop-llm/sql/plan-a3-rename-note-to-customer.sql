-- stage expand_note_col (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
UPDATE account_user SET customer_note = note;
-- stage backfill_sync_note (backfill)
UPDATE account_user SET note = customer_note;
-- stage contract_drop_note (contract)
ALTER TABLE account_user DROP COLUMN note;
