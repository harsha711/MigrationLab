-- stage expand_column (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
UPDATE account_user SET customer_note = note;
-- stage add_sync_triggers (expand)
CREATE OR REPLACE FUNCTION sync_note_customer_note() RETURNS TRIGGER AS $$
BEGIN
  NEW.customer_note := COALESCE(NEW.customer_note, NEW.note);
  NEW.note := COALESCE(NEW.note, NEW.customer_note);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_customer_note_trigger
  AFTER INSERT OR UPDATE ON account_user
  FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note();
-- stage contract_column (contract)
DROP TRIGGER IF EXISTS sync_note_customer_note_trigger ON account_user;
DROP FUNCTION IF EXISTS sync_note_customer_note();
ALTER TABLE account_user DROP COLUMN note;
