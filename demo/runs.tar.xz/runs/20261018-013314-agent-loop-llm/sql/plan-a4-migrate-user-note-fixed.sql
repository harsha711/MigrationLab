-- stage expand_column (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
UPDATE account_user SET customer_note = note;
-- stage add_sync_trigger (expand)
CREATE OR REPLACE FUNCTION sync_note_customer_note() RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.note IS NOT NULL THEN
      NEW.customer_note := NEW.note;
    ELSIF NEW.customer_note IS NOT NULL THEN
      NEW.note := NEW.customer_note;
    END IF;
  ELSIF TG_OP = 'UPDATE' THEN
    IF NEW.note IS DISTINCT FROM OLD.note THEN
      NEW.customer_note := NEW.note;
    END IF;
    IF NEW.customer_note IS DISTINCT FROM OLD.customer_note THEN
      NEW.note := NEW.customer_note;
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_customer_note_trigger
  AFTER INSERT OR UPDATE ON account_user
  FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note();
-- stage contract_column (contract)
DROP TRIGGER IF EXISTS sync_note_customer_note_trigger ON account_user;
DROP FUNCTION IF EXISTS sync_note_customer_note();
ALTER TABLE account_user DROP COLUMN note;
