-- stage e1 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
-- stage b1 (backfill)
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL;
-- stage d1 (contract)
ALTER TABLE account_user DROP COLUMN note;
