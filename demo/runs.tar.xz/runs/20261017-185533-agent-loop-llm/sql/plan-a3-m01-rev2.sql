-- stage e1 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
CREATE OR REPLACE FUNCTION sync_note_customer_note() RETURNS trigger AS \$\$ BEGIN IF NEW.note IS DISTINCT FROM COALESCE(NEW.customer_note, '') THEN NEW.customer_note := NEW.note; ELSIF NEW.customer_note IS DISTINCT FROM COALESCE(NEW.note, '') THEN NEW.note := NEW.customer_note; END IF; RETURN NEW; END; \$\$ LANGUAGE plpgsql;
CREATE TRIGGER sync_on_write AFTER INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note();
-- stage b1 (backfill)
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL;
-- stage d1 (contract)
ALTER TABLE account_user DROP COLUMN note;
