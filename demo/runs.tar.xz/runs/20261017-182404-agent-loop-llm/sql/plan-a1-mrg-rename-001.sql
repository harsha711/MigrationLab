-- stage expand-001 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
CREATE OR REPLACE FUNCTION sync_note_customer_note() RETURNS TRIGGER AS $$ BEGIN NEW.customer_note := COALESCE(NEW.customer_note, NEW.note); NEW.note := COALESCE(NEW.note, NEW.customer_note); RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_cust_note_trig AFTER INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note();
-- stage backfill-001 (backfill)
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL;
-- stage contract-001 (contract)
ALTER TABLE account_user DROP COLUMN note;
