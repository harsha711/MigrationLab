-- stage expand_note_column (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
-- stage backfill_note_values (backfill)
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL;
-- stage add_sync_trigger (backfill)
CREATE OR REPLACE FUNCTION sync_note_customer_note() RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
    IF NEW.note IS DISTINCT FROM COALESCE(OLD.note, '') THEN
      NEW.customer_note := NEW.note;
    END IF;
    IF NEW.customer_note IS DISTINCT FROM COALESCE(OLD.customer_note, '') THEN
      NEW.note := NEW.customer_note;
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER note_sync_trigger AFTER INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note();
-- stage contract_drop_note (contract)
DROP TRIGGER note_sync_trigger ON account_user;
ALTER TABLE account_user DROP COLUMN note;
