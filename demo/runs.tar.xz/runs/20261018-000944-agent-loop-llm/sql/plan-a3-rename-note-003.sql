-- stage expand_note_column (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
-- stage backfill_note_values (backfill)
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL;
-- stage sync_note_columns (backfill) [repeat until 0 rows]
UPDATE account_user SET note = customer_note WHERE note IS DISTINCT FROM customer_note;
-- stage contract_drop_note (contract)
ALTER TABLE account_user DROP COLUMN note;
