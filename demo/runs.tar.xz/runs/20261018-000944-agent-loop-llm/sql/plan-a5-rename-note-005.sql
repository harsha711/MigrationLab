-- stage expand_note_column (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
-- stage backfill_note_values (backfill)
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL;
-- stage add_sync_flag_column (backfill)
ALTER TABLE account_user ADD COLUMN sync_flag BOOLEAN NOT NULL DEFAULT false;
-- stage sync_note_columns (backfill)
CREATE OR REPLACE FUNCTION sync_note_customer_note() RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
    -- sync note ← customer_note
    IF NEW.customer_note IS DISTINCT FROM COALESCE(NEW.note, '') THEN
      IF NOT NEW.sync_flag THEN
        NEW.sync_flag := true;
        NEW.note := NEW.customer_note;
        NEW.sync_flag := false;
      END IF;
    END IF;
    -- sync customer_note ← note
    IF NEW.note IS DISTINCT FROM COALESCE(NEW.customer_note, '') THEN
      IF NOT NEW.sync_flag THEN
        NEW.sync_flag := true;
        NEW.customer_note := NEW.note;
        NEW.sync_flag := false;
      END IF;
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER note_sync_trigger AFTER INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note();
-- stage contract_drop_note (contract)
DROP TRIGGER note_sync_trigger ON account_user;
ALTER TABLE account_user DROP COLUMN note;
ALTER TABLE account_user DROP COLUMN sync_flag;
