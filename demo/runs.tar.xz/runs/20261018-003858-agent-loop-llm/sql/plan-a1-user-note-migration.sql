-- stage stg1_expand (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
UPDATE account_user SET customer_note = note;
CREATE OR REPLACE FUNCTION copy_note_trigger() RETURNS trigger AS $$ BEGIN NEW.note := NEW.customer_note; RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER copy_note_trigger AFTER UPDATE ON account_user FOR EACH ROW WHEN (NEW.customer_note IS DISTINCT FROM OLD.customer_note) EXECUTE FUNCTION copy_note_trigger();
