BEGIN;
--
-- Alter field note on user
--
ALTER TABLE "account_user" ALTER COLUMN "note" TYPE varchar(255) USING "note"::varchar(255);
COMMIT;
