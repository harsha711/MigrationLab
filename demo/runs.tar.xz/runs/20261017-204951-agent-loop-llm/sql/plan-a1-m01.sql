-- stage expand (expand)
ALTER TABLE account_user ADD COLUMN note_new VARCHAR(255);
-- stage backfill (backfill)
UPDATE account_user SET note_new = LEFT(note, 255);
-- stage contract (contract)
ALTER TABLE account_user DROP COLUMN note;
ALTER TABLE account_user RENAME COLUMN note_new TO note;
