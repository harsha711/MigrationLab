-- stage expand_01 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
UPDATE account_user SET customer_note = note;
CREATE OR REPLACE FUNCTION sync_note_customer_note() RETURNS trigger AS $$ BEGIN IF TG_OP = 'INSERT' THEN IF NEW.note IS NOT NULL THEN NEW.customer_note := NEW.note; ELSIF NEW.customer_note IS NOT NULL THEN NEW.note := NEW.customer_note; END IF; ELSIF TG_OP = 'UPDATE' THEN IF NEW.note IS NOT NULL AND NEW.note != OLD.note THEN NEW.customer_note := NEW.note; ELSIF NEW.customer_note IS NOT NULL AND NEW.customer_note != OLD.customer_note THEN NEW.note := NEW.customer_note; END IF; END IF; RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_customer_note BEFORE INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note();
-- stage backfill_01 (backfill)
UPDATE account_user SET customer_note = note;
-- stage contract_01 (contract)
ALTER TABLE account_user DROP COLUMN note;
