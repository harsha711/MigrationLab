-- stage expand_note_column (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
-- stage backfill_note_values (backfill) [repeat until 0 rows]
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL AND note IS NOT NULL;
-- stage sync_note_values (backfill) [repeat until 0 rows]
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL OR customer_note != note;
-- stage contract_drop_old_column (contract)
ALTER TABLE account_user DROP COLUMN note;
