-- stage expand_account_user_note_rename (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
CREATE OR REPLACE FUNCTION sync_bidirectional_note() RETURNS trigger AS $$ BEGIN IF NEW.note IS DISTINCT FROM OLD.note THEN NEW.customer_note := COALESCE(NEW.note, NEW.customer_note); END IF; IF NEW.customer_note IS DISTINCT FROM OLD.customer_note THEN NEW.note := COALESCE(NEW.note, NEW.customer_note); END IF; RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER sync_bidirectional_note AFTER INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_bidirectional_note();
-- stage backfill_account_user_note (backfill) [repeat until 0 rows]
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL AND note IS NOT NULL;
-- stage contract_drop_note_column (contract)
ALTER TABLE account_user DROP COLUMN note;
