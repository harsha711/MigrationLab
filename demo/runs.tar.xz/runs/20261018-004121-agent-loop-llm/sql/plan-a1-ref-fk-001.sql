-- stage clean_orphans (expand)
UPDATE account_user SET referrer_id = NULL WHERE referrer_id IS NOT NULL AND referrer_id NOT IN (SELECT id FROM account_user);
-- stage add_fk_not_valid (expand)
ALTER TABLE account_user ADD CONSTRAINT referrer_id_fk FOREIGN KEY (referrer_id) REFERENCES account_user(id) NOT VALID;
-- stage validate_fk (contract)
ALTER TABLE account_user VALIDATE CONSTRAINT referrer_id_fk;
