-- stage stg_expand (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
-- stage stg_backfill (backfill)
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL;
-- stage stg_create_func (expand)
CREATE OR REPLACE FUNCTION sync_note_customer_note() RETURNS TRIGGER AS $$ BEGIN NEW.note := COALESCE(NEW.note, NEW.customer_note); NEW.customer_note := COALESCE(NEW.customer_note, NEW.note); RETURN NEW; END; $$ LANGUAGE plpgsql;
-- stage stg_create_trigger (expand)
CREATE TRIGGER sync_note_trigger BEFORE INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note();
-- stage stg_contract (contract)
ALTER TABLE account_user DROP COLUMN note;
