-- stage expand_add_column (expand)
ALTER TABLE account_user ADD COLUMN IF NOT EXISTS note TEXT;
ALTER TABLE account_user ALTER COLUMN note SET DEFAULT NULL;
-- stage contract_drop_column (contract)
ALTER TABLE account_user DROP COLUMN note;
