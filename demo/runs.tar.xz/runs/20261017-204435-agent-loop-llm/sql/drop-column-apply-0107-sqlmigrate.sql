BEGIN;
--
-- Remove field note from user
--
ALTER TABLE "account_user" DROP COLUMN "note" CASCADE;
COMMIT;
