-- stage expand_set_null (expand)
ALTER TABLE account_user ALTER COLUMN note SET DEFAULT NULL;
-- stage contract_drop_column (contract)
ALTER TABLE account_user DROP COLUMN note;
