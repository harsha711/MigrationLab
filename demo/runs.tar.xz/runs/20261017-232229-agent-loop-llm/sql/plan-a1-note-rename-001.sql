-- stage expand (expand)
ALTER TABLE account_user ADD COLUMN IF NOT EXISTS customer_note TEXT;
UPDATE account_user SET customer_note = note;
-- stage contract (contract)
ALTER TABLE account_user DROP COLUMN note;
