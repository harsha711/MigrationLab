-- stage expand (expand)
ALTER TABLE account_user ADD COLUMN IF NOT EXISTS customer_note TEXT;
UPDATE account_user SET customer_note = note;
CREATE OR REPLACE FUNCTION sync_note_customer_note() RETURNS trigger AS $$ BEGIN IF TG_OP = 'INSERT' THEN NEW.customer_note := NEW.note; ELSIF TG_OP = 'UPDATE' THEN IF NEW.note IS DISTINCT FROM OLD.note THEN NEW.customer_note := NEW.note; IF NEW.customer_note IS DISTINCT FROM OLD.customer_note THEN NEW.note := NEW.customer_note; END IF; END IF; RETURN NEW; END $$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_customer_note AFTER INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note();
-- stage contract (contract)
DROP TRIGGER IF EXISTS sync_note_customer_note ON account_user;
ALTER TABLE account_user DROP COLUMN note;
