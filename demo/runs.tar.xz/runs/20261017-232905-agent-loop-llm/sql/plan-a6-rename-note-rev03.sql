-- stage expand_01 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
UPDATE account_user SET customer_note = note;
CREATE OR REPLACE FUNCTION sync_note_customer_note() RETURNS TRIGGER AS $$ BEGIN IF TG_OP = 'INSERT' THEN IF NEW.note IS NOT NULL AND NEW.customer_note IS NULL THEN NEW.customer_note := NEW.note; ELSIF NEW.customer_note IS NOT NULL AND NEW.note IS NULL THEN NEW.note := NEW.customer_note; END IF; ELSE IF NEW.note != OLD.note THEN NEW.customer_note := NEW.note; END IF; IF NEW.customer_note != OLD.customer_note THEN NEW.note := NEW.customer_note; END IF; END IF; RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER trg_sync_note BEFORE INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note();
-- stage sync_01 (backfill) [repeat until 0 rows]
UPDATE account_user SET customer_note = note WHERE customer_note IS DISTINCT FROM note;
-- stage contract_01 (contract)
DROP TRIGGER IF EXISTS trg_sync_note ON account_user;
ALTER TABLE account_user DROP COLUMN note;
