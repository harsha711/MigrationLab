-- stage contract (contract)
UPDATE account_user SET note = LEFT(note, 255);
ALTER TABLE account_user ALTER COLUMN note TYPE VARCHAR(255) USING note::varchar(255);
