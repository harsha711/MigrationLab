-- stage expand (expand)
ALTER TABLE account_user ADD COLUMN note_temp VARCHAR(255) DEFAULT NULL;
-- stage backfill (backfill)
UPDATE account_user SET note_temp = note WHERE length(note) <= 255;
-- stage contract (contract)
ALTER TABLE account_user ALTER COLUMN note TYPE VARCHAR(255) USING note::varchar(255);
