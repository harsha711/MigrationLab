-- stage expand_backfill (expand)
UPDATE account_user SET customer_note = note WHERE note IS NOT NULL;
-- stage contract_drop (contract)
ALTER TABLE account_user DROP COLUMN note;
