-- stage expand_note_type (expand)
ALTER TABLE account_user ALTER COLUMN note TYPE varchar(255);
