-- stage truncate_notes (expand) [repeat until 0 rows]
UPDATE account_user SET note = left(note, 255);
-- stage change_column_type (expand)
ALTER TABLE account_user ALTER COLUMN note TYPE varchar(255);
