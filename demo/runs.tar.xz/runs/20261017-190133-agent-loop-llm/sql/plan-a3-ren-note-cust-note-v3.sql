-- stage expand_1 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
CREATE OR REPLACE FUNCTION sync_note_customer_note() RETURNS trigger AS $$ BEGIN IF NEW.note IS DISTINCT FROM OLD.note THEN NEW.customer_note := NEW.note; END IF; IF NEW.customer_note IS DISTINCT FROM OLD.customer_note THEN NEW.note := NEW.customer_note; END IF; RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_customer_note BEFORE INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note();
-- stage backfill_1 (backfill) [repeat until 0 rows]
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL AND note IS NOT NULL;
-- stage contract_1 (contract)
DROP TRIGGER sync_note_customer_note ON account_user;
ALTER TABLE account_user DROP COLUMN note;
