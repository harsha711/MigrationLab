-- stage sql_truncate_notes (backfill)
UPDATE account_user SET note = left(note, 255) WHERE length(note) > 255;
