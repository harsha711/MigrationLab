-- stage expand (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
-- stage backfill (backfill)
UPDATE account_user SET customer_note = note;
