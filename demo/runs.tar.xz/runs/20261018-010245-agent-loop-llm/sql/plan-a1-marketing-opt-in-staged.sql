-- stage expand (expand)
ALTER TABLE account_user ADD COLUMN marketing_opt_in boolean NOT NULL DEFAULT false;
-- stage backfill (backfill)
UPDATE account_user SET marketing_opt_in = false WHERE marketing_opt_in IS NULL;
-- stage contract (contract)
ALTER TABLE account_user ALTER COLUMN marketing_opt_in SET NOT NULL;
