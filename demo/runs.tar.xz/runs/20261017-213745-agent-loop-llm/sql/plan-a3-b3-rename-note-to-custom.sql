-- stage expand-1 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
-- stage backfill-1 (backfill) [repeat until 0 rows]
UPDATE account_user SET customer_note = note WHERE note IS NOT NULL AND customer_note IS NULL;
-- stage sync-1 (contract)
UPDATE account_user SET note = customer_note WHERE customer_note IS NOT NULL;
UPDATE account_user SET customer_note = note WHERE note IS NOT NULL;
-- stage contract-1 (contract)
ALTER TABLE account_user DROP COLUMN note;
