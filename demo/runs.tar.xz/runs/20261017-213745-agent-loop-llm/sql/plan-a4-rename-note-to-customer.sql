-- stage expand-1 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
-- stage backfill-1 (backfill) [repeat until 0 rows]
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL;
-- stage sync-1 (contract)
UPDATE account_user SET note = customer_note;
-- stage contract-1 (contract)
ALTER TABLE account_user DROP COLUMN note;
