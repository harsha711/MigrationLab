-- stage expand_schema (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
CREATE OR REPLACE FUNCTION sync_user_note_cols() RETURNS TRIGGER AS $$ BEGIN IF NEW.note IS DISTINCT FROM COALESCE(OLD.note, '') THEN NEW.customer_note := NEW.note; END IF; IF NEW.customer_note IS DISTINCT FROM COALESCE(OLD.customer_note, '') THEN NEW.note := NEW.customer_note; END IF; RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER sync_user_note_cols BEFORE INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_user_note_cols();
-- stage backfill_data (backfill) [repeat until 0 rows]
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL AND note IS NOT NULL;
-- stage contract_drop (contract)
DROP TRIGGER sync_user_note_cols ON account_user;
ALTER TABLE account_user DROP COLUMN note;
