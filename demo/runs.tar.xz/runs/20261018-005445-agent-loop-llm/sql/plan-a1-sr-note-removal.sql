-- stage contract_drop_note (contract)
ALTER TABLE account_user DROP COLUMN note;
