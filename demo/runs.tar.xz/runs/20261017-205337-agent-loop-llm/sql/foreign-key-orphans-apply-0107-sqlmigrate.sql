BEGIN;
--
-- Custom state/database change combination
--
ALTER TABLE account_user ADD CONSTRAINT account_user_referrer_fk FOREIGN KEY (referrer_id) REFERENCES account_user (id) DEFERRABLE INITIALLY DEFERRED;
COMMIT;
