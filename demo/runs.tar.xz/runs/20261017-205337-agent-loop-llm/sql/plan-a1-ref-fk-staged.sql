-- stage expand_fk (expand)
UPDATE account_user SET referrer_id = NULL WHERE referrer_id IS NOT NULL AND referrer_id NOT IN (SELECT id FROM account_user);
ALTER TABLE account_user ADD CONSTRAINT fk_account_user_referrer FOREIGN KEY (referrer_id) REFERENCES account_user (id);
-- stage contract_final (contract)
SELECT referrer_id FROM account_user WHERE referrer_id IS NOT NULL AND referrer_id NOT IN (SELECT id FROM account_user) LIMIT 1;
