-- stage expand (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
UPDATE account_user SET customer_note = note;
-- stage contract (contract)
ALTER TABLE account_user ALTER COLUMN note SET DEFAULT NULL;
COMMENT ON COLUMN account_user.note IS 'Deprecated; kept for old app compatibility until retirement.';
