-- stage expand_note_column (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
CREATE OR REPLACE FUNCTION sync_note_customer_note() RETURNS trigger AS $$ BEGIN IF NEW.note IS DISTINCT FROM OLD.note THEN NEW.customer_note := NEW.note; END IF; IF NEW.customer_note IS DISTINCT FROM OLD.customer_note THEN NEW.note := NEW.customer_note; END IF; RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_customer_note AFTER UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note();
-- stage backfill_note_data (backfill)
UPDATE account_user SET customer_note = note WHERE note IS NOT NULL;
-- stage contract_note_column (contract)
ALTER TABLE account_user DROP COLUMN note;
