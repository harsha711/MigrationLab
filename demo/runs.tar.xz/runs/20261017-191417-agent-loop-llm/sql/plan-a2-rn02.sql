-- stage expand_01 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
-- stage backfill_01 (backfill)
UPDATE account_user SET customer_note = note;
-- stage sync_trigger_01 (expand)
CREATE OR REPLACE FUNCTION sync_note_customer_note() RETURNS trigger AS $$;
BEGIN;
  NEW.customer_note := NEW.note;
  NEW.note := COALESCE(NEW.note, NEW.customer_note);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_update;
  BEFORE UPDATE ON account_user;
  FOR EACH ROW;
  EXECUTE FUNCTION sync_note_customer_note();
CREATE TRIGGER sync_note_insert;
  BEFORE INSERT ON account_user;
  FOR EACH ROW;
  EXECUTE FUNCTION sync_note_customer_note();
-- stage contract_01 (contract)
DROP TRIGGER IF EXISTS sync_note_insert ON account_user;
DROP TRIGGER IF EXISTS sync_note_update ON account_user;
DROP FUNCTION IF EXISTS sync_note_customer_note();
ALTER TABLE account_user DROP COLUMN note;
