-- stage expand_01 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
-- stage backfill_01 (backfill)
UPDATE account_user SET customer_note = note;
-- stage func_01 (expand)
CREATE OR REPLACE FUNCTION sync_note_customer_note() RETURNS trigger AS $$ BEGIN IF (TG_OP = 'INSERT' OR TG_OP = 'UPDATE') THEN IF NEW.note IS DISTINCT FROM COALESCE(OLD.note, '') THEN NEW.customer_note := NEW.note; END IF; IF NEW.customer_note IS DISTINCT FROM COALESCE(OLD.customer_note, '') THEN NEW.note := NEW.customer_note; END IF; END IF; RETURN NEW; END; $$ LANGUAGE plpgsql;
-- stage trigger_01 (expand)
CREATE TRIGGER sync_note_br BEFORE INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note();
-- stage contract_01 (contract)
DROP TRIGGER IF EXISTS sync_note_br ON account_user;
DROP FUNCTION IF EXISTS sync_note_customer_note();
ALTER TABLE account_user DROP COLUMN note;
