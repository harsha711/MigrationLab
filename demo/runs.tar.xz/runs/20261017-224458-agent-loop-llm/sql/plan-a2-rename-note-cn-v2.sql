-- stage expand (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
CREATE OR REPLACE FUNCTION sync_user_note_customer_note() RETURNS trigger AS $$ BEGIN IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN NEW.customer_note := COALESCE(NEW.note, NEW.customer_note); NEW.note := COALESCE(NEW.note, NEW.customer_note); RETURN NEW; END IF; RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER sync_user_note_customer_note BEFORE INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_user_note_customer_note();
-- stage backfill (backfill) [repeat until 0 rows]
UPDATE account_user SET customer_note = note WHERE customer_note IS DISTINCT FROM note;
-- stage contract (contract)
DROP TRIGGER sync_user_note_customer_note ON account_user;
ALTER TABLE account_user DROP COLUMN note;
