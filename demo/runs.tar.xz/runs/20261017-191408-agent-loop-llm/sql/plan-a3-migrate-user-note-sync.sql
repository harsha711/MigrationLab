-- stage expand_1 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
CREATE OR REPLACE FUNCTION sync_note_customer_note() RETURNS trigger AS $$ BEGIN IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN NEW.customer_note := COALESCE(NEW.customer_note, NEW.note); NEW.note := COALESCE(NEW.note, NEW.customer_note); RETURN NEW; END IF; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_customer_note AFTER INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note();
-- stage backfill_1 (backfill)
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL;
-- stage contract_1 (contract)
ALTER TABLE account_user DROP COLUMN note;
