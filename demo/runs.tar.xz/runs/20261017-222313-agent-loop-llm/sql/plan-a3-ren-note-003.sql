-- stage expand_note (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
-- stage contract_note (contract)
UPDATE account_user SET customer_note = note WHERE note IS NOT NULL AND customer_note IS NULL;
ALTER TABLE account_user DROP COLUMN note;
