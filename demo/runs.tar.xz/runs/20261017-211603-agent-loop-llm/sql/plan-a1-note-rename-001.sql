-- stage expand_001 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
-- stage backfill_001 (backfill)
UPDATE account_user SET customer_note = note;
-- stage contract_001 (contract)
ALTER TABLE account_user DROP COLUMN note;
