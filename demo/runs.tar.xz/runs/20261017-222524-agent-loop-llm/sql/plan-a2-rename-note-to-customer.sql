-- stage expand_customer_note (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
-- stage backfill_customer_note (backfill)
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL;
-- stage contract_drop_note (contract)
ALTER TABLE account_user DROP COLUMN note;
