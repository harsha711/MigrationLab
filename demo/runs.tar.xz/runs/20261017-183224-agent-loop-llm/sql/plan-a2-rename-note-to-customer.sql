-- stage expand_1 (expand)
ALTER TABLE account_user ADD COLUMN customer_note text NULL;
-- stage backfill_1 (backfill)
UPDATE account_user SET customer_note = note;
-- stage sync_trigger_1 (expand)
CREATE OR REPLACE FUNCTION sync_note_to_customer_note() RETURNS TRIGGER AS \$\$ BEGIN NEW.customer_note := NEW.note; RETURN NEW; END; \$\$ LANGUAGE plpgsql; CREATE TRIGGER note_to_customer_note AFTER INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_to_customer_note();
-- stage contract_1 (contract)
DROP TRIGGER note_to_customer_note ON account_user; DROP FUNCTION sync_note_to_customer_note(); ALTER TABLE account_user DROP COLUMN note;
