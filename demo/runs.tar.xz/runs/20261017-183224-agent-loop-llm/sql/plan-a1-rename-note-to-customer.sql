-- stage expand_1 (expand)
ALTER TABLE account_user ADD COLUMN customer_note text NULL;
-- stage backfill_1 (backfill) [repeat until 0 rows]
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL;
-- stage sync_trigger_1 (expand)
CREATE OR REPLACE FUNCTION sync_note_customer_note() RETURNS TRIGGER AS $$ BEGIN IF NEW.note IS DISTINCT FROM NEW.customer_note THEN NEW.customer_note := NEW.note; END IF; IF NEW.customer_note IS DISTINCT FROM NEW.note THEN NEW.note := NEW.customer_note; END IF; RETURN NEW; END; $$ LANGUAGE plpgsql; CREATE TRIGGER note_customer_note_sync AFTER INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note();
-- stage contract_1 (contract)
DROP TRIGGER note_customer_note_sync ON account_user; DROP FUNCTION sync_note_customer_note(); ALTER TABLE account_user DROP COLUMN note;
