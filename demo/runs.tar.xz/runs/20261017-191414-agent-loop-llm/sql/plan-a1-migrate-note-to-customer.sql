-- stage stage_expand (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
-- stage stage_backfill (backfill)
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL;
-- stage stage_contract (contract)
ALTER TABLE account_user DROP COLUMN note;
