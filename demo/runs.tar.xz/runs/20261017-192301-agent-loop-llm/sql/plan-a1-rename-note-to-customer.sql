-- stage expand_1 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
-- stage backfill_1 (backfill)
UPDATE account_user SET customer_note = note;
-- stage contract_1 (contract)
ALTER TABLE account_user DROP COLUMN note;
