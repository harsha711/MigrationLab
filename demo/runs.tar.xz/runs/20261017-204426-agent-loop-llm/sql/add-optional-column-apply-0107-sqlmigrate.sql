BEGIN;
--
-- Add field nickname to user
--
ALTER TABLE "account_user" ADD COLUMN "nickname" varchar(256) NULL;
COMMIT;
