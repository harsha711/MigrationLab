-- stage expand_001 (expand)
ALTER TABLE account_user ADD COLUMN marketing_opt_in boolean NOT NULL DEFAULT false;
-- stage backfill_001 (backfill)
UPDATE account_user SET marketing_opt_in = false;
-- stage contract_001 (contract)
SELECT 1;
