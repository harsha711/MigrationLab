BEGIN;
--
-- Add field customer_note to user
--
ALTER TABLE "account_user" ADD COLUMN "customer_note" text NULL;
--
-- Raw Python operation
--
-- THIS OPERATION CANNOT BE WRITTEN AS SQL
COMMIT;
