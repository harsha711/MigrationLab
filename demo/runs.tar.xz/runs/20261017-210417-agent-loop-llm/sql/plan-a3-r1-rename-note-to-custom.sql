-- stage expand_1 (expand)
ALTER TABLE account_user ADD COLUMN IF NOT EXISTS customer_note TEXT;
-- stage backfill_1 (backfill) [repeat until 0 rows]
UPDATE account_user SET customer_note = note WHERE note IS NOT NULL AND customer_note IS NULL;
-- stage sync_triggers_1 (expand)
CREATE OR REPLACE FUNCTION sync_note_to_customer() RETURNS TRIGGER AS $$ BEGIN NEW.customer_note := COALESCE(NEW.note, NEW.customer_note); RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER note_to_customer_trigger BEFORE INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_to_customer();
CREATE OR REPLACE FUNCTION sync_customer_to_note() RETURNS TRIGGER AS $$ BEGIN NEW.note := COALESCE(NEW.customer_note, NEW.note); RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER customer_to_note_trigger BEFORE INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_customer_to_note();
-- stage contract_1 (contract)
ALTER TABLE account_user DROP COLUMN note;
