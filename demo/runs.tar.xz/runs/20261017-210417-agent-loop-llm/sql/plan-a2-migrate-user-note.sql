-- stage expand_customer_note (expand)
ALTER TABLE account_user ADD COLUMN IF NOT EXISTS customer_note TEXT;
-- stage backfill_notes (backfill)
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL;
