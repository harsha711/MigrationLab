-- stage expand_init (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
UPDATE account_user SET customer_note = note;
CREATE OR REPLACE FUNCTION sync_note_to_customer_note() RETURNS trigger AS $$ BEGIN NEW.customer_note := NEW.note; RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_to_customer_note AFTER UPDATE ON account_user WHEN (OLD.note IS DISTINCT FROM NEW.note) EXECUTE FUNCTION sync_note_to_customer_note();
CREATE OR REPLACE FUNCTION sync_customer_note_to_note() RETURNS trigger AS $$ BEGIN NEW.note := NEW.customer_note; RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER sync_customer_note_to_note AFTER UPDATE ON account_user WHEN (OLD.customer_note IS DISTINCT FROM NEW.customer_note) EXECUTE FUNCTION sync_customer_note_to_note();
-- stage backfill_sync (backfill)
UPDATE account_user SET customer_note = note;
-- stage contract_drop (contract)
DROP TRIGGER IF EXISTS sync_customer_note_to_note ON account_user;
DROP TRIGGER IF EXISTS sync_note_to_customer_note ON account_user;
DROP FUNCTION IF EXISTS sync_customer_note_to_note();
DROP FUNCTION IF EXISTS sync_note_to_customer_note();
ALTER TABLE account_user DROP COLUMN note;
