-- stage expand-customer_note (expand)
DO $$ BEGIN IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='account_user' AND column_name='customer_note') THEN ALTER TABLE account_user ADD COLUMN customer_note TEXT; END IF; END $$;
-- stage backfill-notes (backfill)
UPDATE account_user SET customer_note = note;
-- stage contract-drop-note (contract)
ALTER TABLE account_user DROP COLUMN note;
