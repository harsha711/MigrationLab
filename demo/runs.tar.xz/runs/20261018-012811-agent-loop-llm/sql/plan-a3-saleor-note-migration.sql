-- stage expand1 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
CREATE OR REPLACE FUNCTION sync_note_from_customer_note() RETURNS trigger AS $$ BEGIN NEW.note := NEW.customer_note; RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_from_customer_note AFTER UPDATE OF customer_note ON account_user FOR EACH ROW WHEN (NEW.customer_note IS DISTINCT FROM OLD.customer_note) EXECUTE PROCEDURE sync_note_from_customer_note();
-- stage backfill1 (backfill)
UPDATE account_user SET customer_note = note;
