-- stage expand_add_col (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
UPDATE account_user SET customer_note = note;
CREATE OR REPLACE FUNCTION sync_user_note_col() RETURNS TRIGGER AS $$ BEGIN IF NEW.note != OLD.note THEN NEW.customer_note := NEW.note; ELSIF NEW.customer_note != OLD.customer_note THEN NEW.note := NEW.customer_note; END IF; RETURN NEW; END; $$ LANGUAGE plpgsql;
-- stage contract_drop_note (contract)
ALTER TABLE account_user DROP COLUMN note;
