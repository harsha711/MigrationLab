-- stage expand_1 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
UPDATE account_user SET customer_note = note;
CREATE OR REPLACE FUNCTION sync_note_customer_note() RETURNS TRIGGER AS $$ BEGIN IF NEW.note IS DISTINCT FROM COALESCE(OLD.note, '') THEN NEW.customer_note := NEW.note; END IF; IF NEW.customer_note IS DISTINCT FROM COALESCE(OLD.customer_note, '') THEN NEW.note := NEW.customer_note; END IF; RETURN NEW; END $$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_customer_note AFTER INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note();
-- stage backfill_1 (backfill)
UPDATE account_user SET customer_note = note WHERE customer_note IS DISTINCT FROM note;
-- stage contract_1 (contract)
DROP TRIGGER sync_note_customer_note ON account_user;
DROP FUNCTION sync_note_customer_note();
ALTER TABLE account_user DROP COLUMN note;
