-- stage expand_001 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
UPDATE account_user SET customer_note = note;
CREATE OR REPLACE FUNCTION sync_note_to_customer_note() RETURNS TRIGGER AS $$ BEGIN IF NEW.note IS DISTINCT FROM COALESCE(OLD.note, '') THEN NEW.customer_note := NEW.note; END IF; RETURN NEW; END $$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_after_note_change AFTER INSERT OR UPDATE ON account_user WHEN NEW.note IS DISTINCT FROM COALESCE(OLD.note, '') FOR EACH ROW EXECUTE FUNCTION sync_note_to_customer_note();
CREATE OR REPLACE FUNCTION sync_customer_note_to_note() RETURNS TRIGGER AS $$ BEGIN IF NEW.customer_note IS DISTINCT FROM COALESCE(OLD.customer_note, '') THEN NEW.note := NEW.customer_note; END IF; RETURN NEW; END $$ LANGUAGE plpgsql;
CREATE TRIGGER sync_customer_note_after_change AFTER INSERT OR UPDATE ON account_user WHEN NEW.customer_note IS DISTINCT FROM COALESCE(OLD.customer_note, '') FOR EACH ROW EXECUTE FUNCTION sync_customer_note_to_note();
-- stage backfill_001 (backfill)
UPDATE account_user SET customer_note = note;
-- stage contract_001 (contract)
DROP TRIGGER sync_note_after_note_change ON account_user;
DROP TRIGGER sync_customer_note_after_change ON account_user;
DROP FUNCTION sync_note_to_customer_note();
DROP FUNCTION sync_customer_note_to_note();
ALTER TABLE account_user DROP COLUMN note;
