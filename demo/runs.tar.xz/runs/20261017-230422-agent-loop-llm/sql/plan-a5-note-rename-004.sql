-- stage expand (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
-- stage backfill (backfill)
UPDATE account_user SET customer_note = note WHERE note IS NOT NULL;
-- stage sync_trigger (expand)
CREATE OR REPLACE FUNCTION sync_note_customer_note() RETURNS trigger AS $$ BEGIN NEW.note := NEW.customer_note; NEW.customer_note := NEW.note; RETURN NEW; END; $$ LANGUAGE plpgsql; CREATE TRIGGER sync_note_customer_note_trig AFTER INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note();
-- stage contract (contract)
ALTER TABLE account_user DROP COLUMN note;
