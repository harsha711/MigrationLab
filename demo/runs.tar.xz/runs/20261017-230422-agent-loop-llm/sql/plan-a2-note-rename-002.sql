-- stage expand (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
-- stage backfill (backfill)
UPDATE account_user SET customer_note = note WHERE note IS NOT NULL;
-- stage sync_trigger (expand)
CREATE OR REPLACE FUNCTION sync_note_customer_note() RETURNS trigger AS $$ BEGIN IF TG_OP = 'INSERT' THEN NEW.customer_note := COALESCE(NEW.note, NEW.customer_note); RETURN NEW; ELSIF TG_OP = 'UPDATE' THEN IF NEW.note IS DISTINCT FROM OLD.note THEN NEW.customer_note := NEW.note; END IF; IF NEW.customer_note IS DISTINCT FROM OLD.customer_note THEN NEW.note := NEW.customer_note; END IF; RETURN NEW; END IF; END; $$ LANGUAGE plpgsql; CREATE TRIGGER sync_note_customer_note_trig AFTER INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note();
-- stage contract (contract)
ALTER TABLE account_user DROP COLUMN note;
