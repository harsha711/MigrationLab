-- stage expand_add_col (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
-- stage backfill_data (backfill) [repeat until 0 rows]
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL AND note IS NOT NULL;
-- stage contract_drop_col (contract)
ALTER TABLE account_user DROP COLUMN note;
