-- stage expand_add_col (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
-- stage backfill_data (backfill) [repeat until 0 rows]
UPDATE account_user SET customer_note = note;
-- stage sync_note (backfill)
UPDATE account_user SET note = customer_note;
-- stage sync_after_deploy (backfill)
UPDATE account_user SET note = customer_note;
-- stage contract_drop_col (contract)
ALTER TABLE account_user DROP COLUMN note;
