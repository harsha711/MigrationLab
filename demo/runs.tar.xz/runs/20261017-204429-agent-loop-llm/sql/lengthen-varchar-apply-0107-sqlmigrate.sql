BEGIN;
--
-- Alter field last_name on user
--
ALTER TABLE "account_user" ALTER COLUMN "last_name" TYPE varchar(512);
COMMIT;
