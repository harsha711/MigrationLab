-- stage expand_01 (expand)
ALTER TABLE account_user ADD COLUMN IF NOT EXISTS customer_note TEXT NULL;
-- stage backfill_01 (backfill)
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL;
-- stage contract_01 (contract)
ALTER TABLE account_user DROP COLUMN note;
