-- stage expand_01 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
-- stage backfill_01 (backfill)
UPDATE account_user SET customer_note = note WHERE note IS DISTINCT FROM customer_note;
-- stage contract_01 (contract)
ALTER TABLE account_user DROP COLUMN note;
