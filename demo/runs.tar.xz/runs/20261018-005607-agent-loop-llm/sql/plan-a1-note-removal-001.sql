-- stage contract_note_column (contract)
ALTER TABLE account_user DROP COLUMN note;
