-- stage expand_1 (expand)
ALTER TABLE account_user ADD COLUMN marketing_opt_in BOOLEAN DEFAULT FALSE;
-- stage backfill_1 (backfill)
UPDATE account_user SET marketing_opt_in = FALSE WHERE marketing_opt_in IS NULL;
-- stage contract_1 (contract)
ALTER TABLE account_user ALTER COLUMN marketing_opt_in SET NOT NULL;
