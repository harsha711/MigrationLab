BEGIN;
--
-- Add field marketing_opt_in to user
--
ALTER TABLE "account_user" ADD COLUMN "marketing_opt_in" boolean DEFAULT false NOT NULL;
ALTER TABLE "account_user" ALTER COLUMN "marketing_opt_in" DROP DEFAULT;
COMMIT;
