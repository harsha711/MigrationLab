-- stage expand_cols (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
-- stage backfill_note (backfill)
UPDATE account_user SET customer_note = note;
-- stage create_sync_trigger (expand)
CREATE OR REPLACE FUNCTION sync_note_customer_note_trigger() RETURNS trigger AS $$ BEGIN IF NEW.note IS DISTINCT FROM COALESCE(OLD.note, '') THEN NEW.customer_note := NEW.note; END IF; IF NEW.customer_note IS DISTINCT FROM COALESCE(OLD.customer_note, '') THEN NEW.note := NEW.customer_note; END IF; RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_customer_note_trigger AFTER INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note_trigger();
-- stage contract_note_col (contract)
DROP TRIGGER sync_note_customer_note_trigger ON account_user;
ALTER TABLE account_user DROP COLUMN note;
