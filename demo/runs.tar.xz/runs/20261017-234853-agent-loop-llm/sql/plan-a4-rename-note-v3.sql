-- stage expand_cols (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
ALTER TABLE account_user ADD COLUMN mod_ts TIMESTAMP WITH TIME ZONE DEFAULT now();
-- stage backfill_note (backfill) [repeat until 0 rows]
UPDATE account_user SET customer_note = note, mod_ts = now() WHERE customer_note IS NULL AND note IS NOT NULL;
-- stage create_mod_ts_trigger (expand)
CREATE OR REPLACE FUNCTION set_mod_ts_trigger() RETURNS trigger AS $$ BEGIN NEW.mod_ts = now(); RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER mod_ts_trigger BEFORE INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION set_mod_ts_trigger();
-- stage create_sync_trigger (expand)
CREATE OR REPLACE FUNCTION sync_note_customer_note_trigger() RETURNS trigger AS $$ BEGIN IF NEW.note IS DISTINCT FROM COALESCE(OLD.note, '') THEN IF OLD.mod_ts IS NULL OR NEW.mod_ts > OLD.mod_ts THEN NEW.customer_note := NEW.note; END IF; END IF; IF NEW.customer_note IS DISTINCT FROM COALESCE(OLD.customer_note, '') THEN IF OLD.mod_ts IS NULL OR NEW.mod_ts > OLD.mod_ts THEN NEW.note := NEW.customer_note; END IF; END IF; RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_customer_note_trigger AFTER INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note_trigger();
-- stage contract_note_col (contract)
ALTER TABLE account_user DROP COLUMN note;
