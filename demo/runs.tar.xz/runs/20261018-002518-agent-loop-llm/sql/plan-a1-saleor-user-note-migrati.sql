-- stage s2 (backfill)
UPDATE account_user SET customer_note = note;
-- stage s4 (contract)
ALTER TABLE account_user DROP COLUMN note;
