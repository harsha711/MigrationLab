-- stage s1 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
-- stage s2 (backfill)
UPDATE account_user SET customer_note = note;
