-- stage backfill-001 (backfill)
UPDATE account_user SET customer_note = note;
