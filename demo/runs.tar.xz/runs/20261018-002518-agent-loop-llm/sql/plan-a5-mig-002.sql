-- stage backfill-notes (backfill)
UPDATE account_user SET customer_note = note;
