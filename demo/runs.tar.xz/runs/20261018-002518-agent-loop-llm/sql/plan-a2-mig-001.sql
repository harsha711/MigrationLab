-- stage expand-column (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
-- stage backfill-notes (backfill)
UPDATE account_user SET customer_note = note;
