-- stage alter_note_type (contract)
ALTER TABLE account_user ALTER COLUMN note TYPE varchar(255) USING note::varchar(255);
