-- stage truncate_notes (expand)
UPDATE account_user SET note = left(note, 255) WHERE length(note) > 255;
-- stage alter_note_column (contract)
ALTER TABLE account_user ALTER COLUMN note TYPE varchar(255) USING note::varchar(255);
