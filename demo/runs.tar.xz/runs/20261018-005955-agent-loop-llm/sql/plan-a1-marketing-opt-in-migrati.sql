-- stage expand_column (expand)
ALTER TABLE account_user ADD COLUMN marketing_opt_in BOOLEAN NULL DEFAULT FALSE;
-- stage backfill_false (backfill)
UPDATE account_user SET marketing_opt_in = FALSE WHERE marketing_opt_in IS NULL;
-- stage contract_not_null (contract)
ALTER TABLE account_user ALTER COLUMN marketing_opt_in SET NOT NULL;
