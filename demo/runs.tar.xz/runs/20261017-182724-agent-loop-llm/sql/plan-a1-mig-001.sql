-- stage expand-001 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
-- stage backfill-001 (backfill)
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL;
-- stage contract-001 (contract)
ALTER TABLE account_user DROP COLUMN note;
