--
-- Concurrently create index account_user_last_name_btree on field(s) last_name of model user
--
CREATE INDEX CONCURRENTLY "account_user_last_name_btree" ON "account_user" USING btree ("last_name");
