-- stage clean_orphaned_referrer (backfill)
UPDATE account_user SET referrer_id = NULL WHERE referrer_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM account_user u2 WHERE u2.id = account_user.referrer_id);
-- stage add_fk_constraint (contract)
ALTER TABLE account_user ADD CONSTRAINT referrer_id_fk FOREIGN KEY (referrer_id) REFERENCES account_user(id);
