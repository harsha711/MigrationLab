-- stage expand (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
-- stage backfill (backfill)
UPDATE account_user SET customer_note = note WHERE note IS NOT NULL;
-- stage sync_trigger (expand)
CREATE OR REPLACE FUNCTION sync_user_note() RETURNS trigger AS $$
BEGIN
  NEW.customer_note := NEW.note;
  NEW.note := NEW.customer_note;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER sync_user_note_trigger BEFORE INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_user_note();
-- stage contract (contract)
DROP TRIGGER sync_user_note_trigger ON account_user;
ALTER TABLE account_user DROP COLUMN note;
