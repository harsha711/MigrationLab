-- stage expand (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
UPDATE account_user SET customer_note = note;
CREATE OR REPLACE FUNCTION sync_note_customer_note() RETURNS TRIGGER AS $$ BEGIN IF TG_OP = 'INSERT' THEN NEW.customer_note := COALESCE(NEW.customer_note, NEW.note); NEW.note := COALESCE(NEW.note, NEW.customer_note); ELSIF TG_OP = 'UPDATE' THEN NEW.customer_note := COALESCE(NEW.customer_note, NEW.note); NEW.note := COALESCE(NEW.note, NEW.customer_note); END IF; RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER note_customer_sync BEFORE INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note();
-- stage contract (contract)
ALTER TABLE account_user DROP COLUMN note;
