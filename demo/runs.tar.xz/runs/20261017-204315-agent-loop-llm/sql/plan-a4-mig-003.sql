-- stage expand-1 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
-- stage backfill-1 (backfill) [repeat until 0 rows]
UPDATE account_user SET customer_note = note WHERE note IS NOT NULL AND customer_note IS NULL;
-- stage expand-2 (expand)
CREATE OR REPLACE FUNCTION sync_note_to_customer() RETURNS trigger AS \$\$ BEGIN NEW.customer_note := NEW.note; RETURN NEW; END; \$\$ LANGUAGE plpgsql; CREATE TRIGGER trg_note_to_customer AFTER UPDATE OF note ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_to_customer(); CREATE OR REPLACE FUNCTION sync_customer_to_note() RETURNS trigger AS \$\$ BEGIN NEW.note := NEW.customer_note; RETURN NEW; END; \$\$ LANGUAGE plpgsql; CREATE TRIGGER trg_customer_to_note AFTER UPDATE OF customer_note ON account_user FOR EACH ROW EXECUTE FUNCTION sync_customer_to_note();
-- stage contract-1 (contract)
ALTER TABLE account_user DROP COLUMN note;
