-- stage expand_01 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
UPDATE account_user SET customer_note = note;
CREATE OR REPLACE FUNCTION set_customer_note_from_note() RETURNS trigger AS $$ BEGIN NEW.customer_note := NEW.note; RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE OR REPLACE FUNCTION set_note_from_customer_note() RETURNS trigger AS $$ BEGIN NEW.note := NEW.customer_note; RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_to_customer_note BEFORE INSERT OR UPDATE ON account_user FOR EACH ROW WHEN (NEW.note IS DISTINCT FROM COALESCE(OLD.note, '')) EXECUTE PROCEDURE set_customer_note_from_note();
CREATE TRIGGER sync_customer_note_to_note BEFORE INSERT OR UPDATE ON account_user FOR EACH ROW WHEN (NEW.customer_note IS DISTINCT FROM COALESCE(OLD.customer_note, '')) EXECUTE PROCEDURE set_note_from_customer_note();
-- stage contract_01 (contract)
DROP TRIGGER sync_note_to_customer_note ON account_user;
DROP TRIGGER sync_customer_note_to_note ON account_user;
DROP FUNCTION set_customer_note_from_note();
DROP FUNCTION set_note_from_customer_note();
ALTER TABLE account_user DROP COLUMN note;
