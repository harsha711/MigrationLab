-- stage expand_01 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
UPDATE account_user SET customer_note = note;
-- stage contract_01 (contract)
ALTER TABLE account_user DROP COLUMN note;
