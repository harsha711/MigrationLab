-- stage expand_01 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
UPDATE account_user SET customer_note = note;
DO $$ CREATE OR REPLACE FUNCTION sync_note_columns() RETURNS trigger AS $$ BEGIN IF TG_OP = 'INSERT' THEN IF NEW.note IS NULL AND NEW.customer_note IS NULL THEN NEW.note := NULL; NEW.customer_note := NULL; ELSIF NEW.note IS NULL THEN NEW.note := NEW.customer_note; ELSIF NEW.customer_note IS NULL THEN NEW.customer_note := NEW.note; END IF; ELSIF TG_OP = 'UPDATE' THEN IF NEW.note IS DISTINCT FROM COALESCE(OLD.note, '') THEN NEW.customer_note := NEW.note; END IF; IF NEW.customer_note IS DISTINCT FROM COALESCE(OLD.customer_note, '') THEN NEW.note := NEW.customer_note; END IF; END; $$ LANGUAGE plpgsql; CREATE TRIGGER sync_note_columns BEFORE INSERT OR UPDATE ON account_user EXECUTE PROCEDURE sync_note_columns(); $$;
-- stage contract_01 (contract)
DROP TRIGGER sync_note_columns ON account_user;
DROP FUNCTION sync_note_columns();
ALTER TABLE account_user DROP COLUMN note;
