-- stage add_unique_lname_constraint (contract)
ALTER TABLE account_user ADD CONSTRAINT user_last_name_key UNIQUE (last_name);
