-- stage add_unique_constraint (contract)
ALTER TABLE account_user ADD CONSTRAINT uk_account_user_last_name UNIQUE (last_name);
-- stage validate_constraint (contract)
ALTER TABLE account_user VALIDATE CONSTRAINT uk_account_user_last_name;
