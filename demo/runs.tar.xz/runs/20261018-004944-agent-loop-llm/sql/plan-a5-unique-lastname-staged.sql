-- stage add_not_valid_unique (expand)
ALTER TABLE account_user ADD CONSTRAINT uk_account_user_last_name UNIQUE (last_name) NOT VALID;
-- stage validate_unique (contract)
ALTER TABLE account_user VALIDATE CONSTRAINT uk_account_user_last_name;
