-- stage add_unique_contract (contract)
ALTER TABLE account_user ADD CONSTRAINT uk_account_user_last_name UNIQUE (last_name);
