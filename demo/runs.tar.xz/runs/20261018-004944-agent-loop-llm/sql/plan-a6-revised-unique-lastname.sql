-- stage add_not_valid_unique (expand)
CREATE UNIQUE INDEX uk_account_user_last_name ON account_user (last_name) WHERE last_name IS NOT NULL AND last_name != '' NOT VALID;
-- stage validate_unique (contract)
ALTER INDEX uk_account_user_last_name VALIDATE CONSTRAINT;
