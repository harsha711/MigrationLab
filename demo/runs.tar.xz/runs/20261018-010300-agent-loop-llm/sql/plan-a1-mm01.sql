-- stage expand_01 (expand)
ALTER TABLE account_user ADD COLUMN marketing_opt_in boolean NOT NULL DEFAULT false;
