-- stage expand_note_column_and_trigger (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL;
CREATE OR REPLACE FUNCTION sync_user_note() RETURNS TRIGGER AS $$ BEGIN NEW.note := COALESCE(NEW.note, NEW.customer_note); NEW.customer_note := COALESCE(NEW.customer_note, NEW.note); RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER user_note_sync BEFORE INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_user_note();
-- stage contract_drop_note (contract)
DROP TRIGGER user_note_sync ON account_user;
ALTER TABLE account_user DROP COLUMN note;
