-- stage expand_note_column_and_trigger (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL;
CREATE OR REPLACE FUNCTION sync_note_customer_note() RETURNS TRIGGER AS $$ BEGIN NEW.customer_note := COALESCE(NEW.note, NEW.customer_note); RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER note_sync_trigger BEFORE INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note();
-- stage contract_drop_note (contract)
DROP TRIGGER note_sync_trigger ON account_user;
ALTER TABLE account_user DROP COLUMN note;
