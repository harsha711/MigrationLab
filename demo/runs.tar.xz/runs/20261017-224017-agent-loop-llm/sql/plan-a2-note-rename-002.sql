-- stage expand_1 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
CREATE OR REPLACE FUNCTION sync_note_value() RETURNS trigger AS $$ BEGIN NEW.customer_note := COALESCE(NEW.customer_note, NEW.note); NEW.note := COALESCE(NEW.note, NEW.customer_note); RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_trig BEFORE INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_value();
-- stage backfill_1 (backfill)
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL;
-- stage drop_trigger_1 (contract)
DROP TRIGGER sync_note_trig ON account_user;
DROP FUNCTION IF EXISTS sync_note_value();
-- stage contract_1 (contract)
ALTER TABLE account_user DROP COLUMN note;
