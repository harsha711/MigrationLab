-- stage expand_001 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
UPDATE account_user SET customer_note = note WHERE note IS NOT NULL;
CREATE OR REPLACE FUNCTION sync_note_trigger() RETURNS TRIGGER AS $$ BEGIN NEW.customer_note := COALESCE(NEW.customer_note, NEW.note); RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_trigger BEFORE INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_trigger();
-- stage contract_001 (contract)
ALTER TABLE account_user DROP COLUMN note;
