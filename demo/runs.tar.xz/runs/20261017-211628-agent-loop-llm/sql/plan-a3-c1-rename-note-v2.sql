-- stage expand_1 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
UPDATE account_user SET customer_note = note;
CREATE OR REPLACE FUNCTION sync_note_cn_trigger() RETURNS trigger AS $$ BEGIN IF NEW.note IS NOT NULL AND NEW.note IS DISTINCT FROM COALESCE(OLD.note, '') THEN NEW.customer_note := NEW.note; ELSIF NEW.customer_note IS NOT NULL AND NEW.customer_note IS DISTINCT FROM COALESCE(OLD.customer_note, '') THEN NEW.note := NEW.customer_note; END IF; RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_cn BEFORE INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_cn_trigger();
-- stage contract_1 (contract)
SELECT note, customer_note FROM account_user LIMIT 1;
-- stage contract_2 (contract)
DROP TRIGGER sync_note_cn;
ALTER TABLE account_user DROP COLUMN note;
