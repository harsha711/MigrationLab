-- stage expand_1 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
UPDATE account_user SET customer_note = note;
-- stage contract_1 (contract)
SELECT note, customer_note FROM account_user LIMIT 1;
-- stage contract_2 (contract)
ALTER TABLE account_user DROP COLUMN note;
