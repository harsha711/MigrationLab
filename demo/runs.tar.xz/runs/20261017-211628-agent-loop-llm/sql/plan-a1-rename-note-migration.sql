-- stage expand_1 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL;
CREATE OR REPLACE FUNCTION sync_note_cn_trigger() RETURNS trigger AS $$ BEGIN IF NEW.note <> OLD.note THEN NEW.customer_note := NEW.note; ELSIF NEW.customer_note <> OLD.customer_note THEN NEW.note := NEW.customer_note; END IF; RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_cn AFTER UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_cn_trigger();
-- stage contract_1 (contract)
SELECT note, customer_note FROM account_user LIMIT 1;
-- stage contract_2 (contract)
ALTER TABLE account_user DROP COLUMN note;
