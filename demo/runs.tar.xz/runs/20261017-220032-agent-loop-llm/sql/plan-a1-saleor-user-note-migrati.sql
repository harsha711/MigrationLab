-- stage expand1 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
-- stage backfill1 (backfill)
UPDATE account_user SET customer_note = note;
-- stage contract1 (contract)
ALTER TABLE account_user DROP COLUMN note;
