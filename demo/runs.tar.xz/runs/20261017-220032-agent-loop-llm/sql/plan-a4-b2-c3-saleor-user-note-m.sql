-- stage backfill_note_to_customer_note (backfill)
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL;
