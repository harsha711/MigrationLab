-- stage expand (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
-- stage backfill (backfill)
UPDATE account_user SET customer_note = note WHERE note IS NOT NULL;
-- stage sync (expand)
CREATE OR REPLACE FUNCTION sync_note_to_customer() RETURNS trigger AS $$ BEGIN NEW.customer_note := NEW.note; RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER note_to_customer_note BEFORE INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_to_customer();
CREATE OR REPLACE FUNCTION sync_customer_to_note() RETURNS trigger AS $$ BEGIN NEW.note := NEW.customer_note; RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER customer_to_note BEFORE INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_customer_to_note();
-- stage contract (contract)
ALTER TABLE account_user DROP COLUMN note;
