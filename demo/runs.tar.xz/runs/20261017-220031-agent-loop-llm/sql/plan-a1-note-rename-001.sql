-- stage expand (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
-- stage backfill (backfill)
UPDATE account_user SET customer_note = note WHERE note IS NOT NULL;
-- stage contract (contract)
ALTER TABLE account_user DROP COLUMN note;
