-- stage expand_1 (expand)
ALTER TABLE account_user ADD COLUMN customer_note text;
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL;
CREATE OR REPLACE FUNCTION sync_user_note() RETURNS trigger AS $$
BEGIN
  NEW.customer_note := COALESCE(NEW.customer_note, NEW.note);
  NEW.note := COALESCE(NEW.note, NEW.customer_note);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_after_insert AFTER INSERT ON account_user FOR EACH ROW EXECUTE FUNCTION sync_user_note();
CREATE TRIGGER sync_note_after_update AFTER UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_user_note();
-- stage contract_1 (contract)
DROP TRIGGER sync_note_after_update ON account_user;
DROP TRIGGER sync_note_after_insert ON account_user;
DROP FUNCTION sync_user_note();
ALTER TABLE account_user DROP COLUMN note;
