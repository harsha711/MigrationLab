-- stage expand_1 (expand)
ALTER TABLE account_user ADD COLUMN customer_note text;
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL;
CREATE OR REPLACE FUNCTION sync_user_note() RETURNS trigger AS $$ BEGIN IF NEW.note IS NOT NULL AND NEW.customer_note IS NULL THEN NEW.customer_note := NEW.note; END IF; IF NEW.customer_note IS NOT NULL AND NEW.note IS NULL THEN NEW.note := NEW.customer_note; END IF; RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_before_insert BEFORE INSERT ON account_user FOR EACH ROW EXECUTE FUNCTION sync_user_note();
CREATE TRIGGER sync_note_before_update BEFORE UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_user_note();
-- stage contract_1 (contract)
DROP TRIGGER sync_note_before_insert ON account_user;
DROP TRIGGER sync_note_before_update ON account_user;
DROP FUNCTION sync_user_note();
ALTER TABLE account_user DROP COLUMN note;
