-- stage expand_1 (expand)
ALTER TABLE account_user ADD COLUMN customer_note text;
UPDATE account_user SET customer_note = note;
-- stage contract_1 (contract)
ALTER TABLE account_user DROP COLUMN note;
