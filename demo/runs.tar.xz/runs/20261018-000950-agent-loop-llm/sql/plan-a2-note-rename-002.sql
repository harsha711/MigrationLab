-- stage expand_0 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
CREATE OR REPLACE FUNCTION sync_note_customer_note() RETURNS trigger AS $$ BEGIN IF TG_OP = 'UPDATE' THEN NEW.note := COALESCE(NEW.note, NEW.customer_note); NEW.customer_note := NEW.note; RETURN NEW; END IF; RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_cust_note BEFORE UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note();
-- stage contract_0 (contract)
ALTER TABLE account_user DROP COLUMN note;
