-- stage expand_0 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
UPDATE account_user SET customer_note = note;
-- stage contract_0 (contract)
ALTER TABLE account_user DROP COLUMN note;
