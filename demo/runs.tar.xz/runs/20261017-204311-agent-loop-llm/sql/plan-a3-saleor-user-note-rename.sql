-- stage expand_note_column (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
-- stage backfill_and_create_triggers (backfill)
UPDATE account_user SET customer_note = note;
CREATE OR REPLACE FUNCTION copy_note_to_customer_note() RETURNS TRIGGER AS $$ BEGIN IF TG_OP = 'INSERT' THEN IF NEW.note IS NOT NULL THEN NEW.customer_note := NEW.note; END IF; ELSIF TG_OP = 'UPDATE' THEN IF NEW.note IS DISTINCT FROM OLD.note THEN IF NEW.note IS NOT NULL THEN NEW.customer_note := NEW.note; END IF; END IF; RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER note_to_customer_note_trig AFTER INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION copy_note_to_customer_note();
CREATE OR REPLACE FUNCTION copy_customer_note_to_note() RETURNS TRIGGER AS $$ BEGIN IF TG_OP = 'INSERT' THEN IF NEW.customer_note IS NOT NULL THEN NEW.note := NEW.customer_note; END IF; ELSIF TG_OP = 'UPDATE' THEN IF NEW.customer_note IS DISTINCT FROM OLD.customer_note THEN IF NEW.customer_note IS NOT NULL THEN NEW.note := NEW.customer_note; END IF; END IF; RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE TRIGGER customer_note_to_note_trig AFTER INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION copy_customer_note_to_note();
-- stage contract_note_column (contract)
ALTER TABLE account_user DROP COLUMN note;
