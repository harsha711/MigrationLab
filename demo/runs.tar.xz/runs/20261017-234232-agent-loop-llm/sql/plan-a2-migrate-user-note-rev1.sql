-- stage expand_001 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
-- stage backfill_001 (backfill)
UPDATE account_user SET customer_note = note WHERE note IS NOT NULL;
-- stage trigger_001 (expand)
CREATE OR REPLACE FUNCTION copy_note_trigger() RETURNS trigger AS $$ BEGIN NEW.customer_note := COALESCE(NEW.customer_note, NEW.note); RETURN NEW; END; $$ LANGUAGE plpgsql; CREATE TRIGGER note_to_customer_note AFTER INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION copy_note_trigger();
-- stage contract_001 (contract)
ALTER TABLE account_user DROP COLUMN note;
