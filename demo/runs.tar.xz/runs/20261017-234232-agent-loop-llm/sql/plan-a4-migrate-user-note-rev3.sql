-- stage expand_001 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
-- stage backfill_001 (backfill)
UPDATE account_user SET customer_note = note WHERE note IS NOT NULL;
-- stage add_source_001 (expand)
ALTER TABLE account_user ADD COLUMN note_source SMALLINT NULL DEFAULT 0;
-- stage sync_triggers_001 (expand)
CREATE OR REPLACE FUNCTION sync_note_to_customer() RETURNS trigger AS $$ BEGIN NEW.customer_note := COALESCE(NEW.customer_note, NEW.note); NEW.note_source := 0; RETURN NEW; END; $$ LANGUAGE plpgsql; CREATE TRIGGER note_to_customer_note AFTER INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_to_customer();
CREATE OR REPLACE FUNCTION sync_customer_to_note() RETURNS trigger AS $$ BEGIN NEW.note := COALESCE(NEW.note, NEW.customer_note); NEW.note_source := 1; RETURN NEW; END; $$ LANGUAGE plpgsql; CREATE TRIGGER customer_note_to_note AFTER INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_customer_to_note();
-- stage contract_001 (contract)
ALTER TABLE account_user DROP COLUMN note;
ALTER TABLE account_user DROP COLUMN note_source;
