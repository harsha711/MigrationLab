-- stage expand_schema (expand)
ALTER TABLE account_user ADD COLUMN IF NOT EXISTS customer_note TEXT NULL;
-- stage backfill_data (backfill) [repeat until 0 rows]
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL AND note IS NOT NULL;
-- stage sync_writes (expand)
CREATE OR REPLACE FUNCTION sync_note_customer_note() RETURNS trigger AS $$
BEGIN
  NEW.customer_note := COALESCE(NEW.customer_note, NEW.note);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_before_upsert
  BEFORE INSERT OR UPDATE ON account_user
  FOR EACH ROW
  EXECUTE FUNCTION sync_note_customer_note();
-- stage contract_schema (contract)
ALTER TABLE account_user DROP COLUMN note;
