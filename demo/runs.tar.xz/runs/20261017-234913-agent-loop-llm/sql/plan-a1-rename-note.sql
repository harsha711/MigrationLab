-- stage expand (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
UPDATE account_user SET customer_note = note;
CREATE OR REPLACE FUNCTION sync_note_customer_note() RETURNS TRIGGER AS $$
BEGIN
  IF NEW.note IS DISTINCT FROM OLD.note THEN
    NEW.customer_note := NEW.note;
  ELSIF NEW.customer_note IS DISTINCT FROM OLD.customer_note THEN
    NEW.note := NEW.customer_note;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_customer AFTER UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note();
-- stage contract (contract)
DROP TRIGGER IF EXISTS sync_note_customer ON account_user;
ALTER TABLE account_user DROP COLUMN note;
