-- stage expand (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
UPDATE account_user SET customer_note = note;
CREATE OR REPLACE FUNCTION sync_note_customer_note() RETURNS TRIGGER AS $$
BEGIN
  NEW.note := COALESCE(NEW.note, NEW.customer_note);
  NEW.customer_note := COALESCE(NEW.customer_note, NEW.note);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_customer AFTER INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note();
-- stage contract (contract)
DROP TRIGGER IF EXISTS sync_note_customer ON account_user;
ALTER TABLE account_user DROP COLUMN note;
