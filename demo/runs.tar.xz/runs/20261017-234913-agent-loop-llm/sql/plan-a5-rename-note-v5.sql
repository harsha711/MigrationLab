-- stage expand (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
UPDATE account_user SET customer_note = note;
CREATE OR REPLACE FUNCTION sync_note_customer_note() RETURNS TRIGGER AS $$
BEGIN
  -- Propagate old‑version note change to customer_note if it is NULL
  IF NEW.note IS DISTINCT FROM COALESCE(OLD.note, '') THEN
    IF NEW.customer_note IS NULL THEN
      NEW.customer_note := NEW.note;
    ELSE
      NEW.customer_note := COALESCE(NEW.customer_note, NEW.note);
    END IF;
  END IF;
  -- Propagate new‑version customer_note change to note if it is NULL
  IF NEW.customer_note IS DISTINCT FROM COALESCE(OLD.customer_note, '') THEN
    IF NEW.note IS NULL THEN
      NEW.note := NEW.customer_note;
    ELSE
      NEW.note := COALESCE(NEW.note, NEW.customer_note);
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_customer AFTER INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note();
-- stage contract (contract)
DROP TRIGGER IF EXISTS sync_note_customer ON account_user;
ALTER TABLE account_user DROP COLUMN note;
