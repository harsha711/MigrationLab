-- stage expand_note_column (expand)
ALTER TABLE account_user ADD COLUMN customer_note text;
-- stage backfill_note_data (backfill) [repeat until 0 rows]
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL AND note IS NOT NULL;
-- stage sync_user_note_trigger (contract)
CREATE OR REPLACE FUNCTION sync_user_note_trigger() RETURNS trigger AS $$ BEGIN IF TG_OP = 'INSERT' THEN NEW.customer_note := COALESCE(NEW.customer_note, NEW.note); NEW.note := COALESCE(NEW.note, NEW.customer_note); ELSIF TG_OP = 'UPDATE' THEN NEW.customer_note := COALESCE(NEW.customer_note, NEW.note); NEW.note := COALESCE(NEW.note, NEW.customer_note); END IF; RETURN NEW; END $$ LANGUAGE plpgsql;
CREATE TRIGGER sync_user_note_after_insert_update AFTER INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_user_note_trigger();
-- stage drop_note_column (contract)
ALTER TABLE account_user DROP COLUMN note;
