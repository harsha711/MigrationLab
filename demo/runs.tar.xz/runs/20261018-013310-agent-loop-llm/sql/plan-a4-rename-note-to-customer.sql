-- stage expand (expand)
ALTER TABLE account_user ADD COLUMN customer_note text;
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL AND note IS NOT NULL;
CREATE OR REPLACE FUNCTION sync_user_note_trigger() RETURNS trigger AS $$ BEGIN IF TG_OP = 'INSERT' THEN NEW.customer_note := NEW.note; ELSIF TG_OP = 'UPDATE' THEN IF NEW.note <> OLD.note THEN NEW.customer_note := NEW.note; ELSIF NEW.customer_note <> OLD.customer_note THEN NEW.note := NEW.customer_note; END IF; END IF; RETURN NEW; END $$ LANGUAGE plpgsql;
CREATE TRIGGER sync_user_note_after_insert_update AFTER INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_user_note_trigger();
-- stage contract (contract)
DROP TRIGGER IF EXISTS sync_user_note_after_insert_update ON account_user;
ALTER TABLE account_user DROP COLUMN note;
