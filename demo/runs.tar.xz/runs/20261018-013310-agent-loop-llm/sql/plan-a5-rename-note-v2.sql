-- stage expand (expand) [repeat until 0 rows]
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL AND note IS NOT NULL;
-- stage sync_trigger (expand)
CREATE OR REPLACE FUNCTION sync_user_note_trigger() RETURNS trigger AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    NEW.customer_note := COALESCE(NEW.customer_note, NEW.note);
    NEW.note := COALESCE(NEW.note, NEW.customer_note);
  ELSIF TG_OP = 'UPDATE' THEN
    NEW.customer_note := COALESCE(NEW.customer_note, NEW.note);
    NEW.note := COALESCE(NEW.note, NEW.customer_note);
  END IF;
  RETURN NEW;
END $$
LANGUAGE plpgsql;
CREATE TRIGGER sync_user_note_after_insert_update
AFTER INSERT OR UPDATE ON account_user
FOR EACH ROW EXECUTE FUNCTION sync_user_note_trigger();
-- stage contract (contract)
ALTER TABLE account_user DROP COLUMN note;
