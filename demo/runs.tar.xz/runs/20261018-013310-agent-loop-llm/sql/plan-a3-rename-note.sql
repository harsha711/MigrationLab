-- stage expand (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
-- stage backfill (backfill) [repeat until 0 rows]
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL AND note IS NOT NULL;
