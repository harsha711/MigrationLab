-- stage expand_col (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
-- stage backfill_data (backfill) [repeat until 0 rows]
UPDATE account_user SET customer_note = note WHERE ctid IN (SELECT ctid FROM account_user WHERE customer_note IS NULL LIMIT 1000);
-- stage contract_col (contract)
ALTER TABLE account_user DROP COLUMN note;
