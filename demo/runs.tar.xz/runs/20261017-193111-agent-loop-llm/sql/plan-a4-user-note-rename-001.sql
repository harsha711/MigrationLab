-- stage expand_col (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
CREATE OR REPLACE FUNCTION sync_note_customer_note() RETURNS TRIGGER AS $$
BEGIN
  NEW.customer_note := COALESCE(NEW.customer_note, NEW.note);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER note_sync_trigger
  AFTER INSERT OR UPDATE ON account_user
  FOR EACH ROW
  EXECUTE FUNCTION sync_note_customer_note();
-- stage backfill_data (backfill) [repeat until 0 rows]
UPDATE account_user SET customer_note = note WHERE ctid IN (SELECT ctid FROM account_user WHERE customer_note IS NULL AND note IS NOT NULL LIMIT 1000);
-- stage contract_col (contract)
ALTER TABLE account_user DROP COLUMN note;
