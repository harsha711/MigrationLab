-- stage expand (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
UPDATE account_user SET customer_note = note;
CREATE OR REPLACE FUNCTION sync_user_note_cols() RETURNS trigger AS $$
BEGIN
  NEW.note := COALESCE(NEW.note, NEW.customer_note);
  NEW.customer_note := COALESCE(NEW.customer_note, NEW.note);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER sync_user_note_cols_trg
  BEFORE INSERT OR UPDATE ON account_user
  FOR EACH ROW EXECUTE FUNCTION sync_user_note_cols();
-- stage contract (contract)
DROP TRIGGER IF EXISTS sync_user_note_cols_trg ON account_user;
DROP FUNCTION IF EXISTS sync_user_note_cols();
ALTER TABLE account_user DROP COLUMN note;
