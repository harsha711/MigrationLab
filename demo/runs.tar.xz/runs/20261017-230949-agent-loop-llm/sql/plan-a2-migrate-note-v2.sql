-- stage expand (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
UPDATE account_user SET customer_note = note;
CREATE OR REPLACE FUNCTION sync_note_customer() RETURNS trigger AS $$
BEGIN
    IF NEW.note IS DISTINCT FROM OLD.note AND NEW.customer_note = OLD.customer_note THEN
        NEW.customer_note := NEW.note;
    ELSIF NEW.customer_note IS DISTINCT FROM OLD.customer_note AND NEW.note = OLD.note THEN
        NEW.note := NEW.customer_note;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_before_update BEFORE UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer();
CREATE TRIGGER sync_note_before_insert BEFORE INSERT ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer();
-- stage contract (contract)
ALTER TABLE account_user DROP COLUMN note;
