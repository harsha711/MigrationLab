-- stage expand (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
UPDATE account_user SET customer_note = note;
CREATE OR REPLACE FUNCTION sync_note_customer() RETURNS trigger AS $$
BEGIN
  NEW.customer_note := COALESCE(NEW.customer_note, NEW.note);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_before_update BEFORE UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer();
CREATE TRIGGER sync_note_before_insert BEFORE INSERT ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer();
-- stage contract (contract)
ALTER TABLE account_user DROP COLUMN note;
