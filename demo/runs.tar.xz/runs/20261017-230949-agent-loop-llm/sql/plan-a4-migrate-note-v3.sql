-- stage expand (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT NULL;
UPDATE account_user SET customer_note = note;
CREATE OR REPLACE FUNCTION sync_note_customer() RETURNS trigger AS $$
BEGIN
    IF NEW.note IS DISTINCT FROM COALESCE(OLD.note, '') THEN
        IF NEW.customer_note IS NULL OR NEW.customer_note = OLD.customer_note THEN
            NEW.customer_note := NEW.note;
        END IF;
    END IF;
    IF NEW.customer_note IS DISTINCT FROM COALESCE(OLD.customer_note, '') THEN
        IF NEW.note IS NULL OR NEW.note = OLD.note THEN
            NEW.note := NEW.customer_note;
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_before_update BEFORE UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer();
CREATE TRIGGER sync_note_before_insert BEFORE INSERT ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer();
-- stage contract (contract)
DROP TRIGGER IF EXISTS sync_note_before_insert ON account_user;
DROP TRIGGER IF EXISTS sync_note_before_update ON account_user;
DROP FUNCTION IF EXISTS sync_note_customer();
ALTER TABLE account_user DROP COLUMN note;
