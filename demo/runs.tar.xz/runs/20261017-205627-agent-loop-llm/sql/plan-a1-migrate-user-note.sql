-- stage expand_schema (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
$$;
CREATE OR REPLACE FUNCTION sync_note_customer_note();
RETURNS TRIGGER AS;
$$;
BEGIN;
  NEW.note := COALESCE(NEW.note, NEW.customer_note);
  NEW.customer_note := COALESCE(NEW.note, NEW.customer_note);
  RETURN NEW;
END;
$$;
LANGUAGE plpgsql;
CREATE TRIGGER sync_note_bu;
BEFORE INSERT OR UPDATE ON account_user;
FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note();
-- stage backfill_data (backfill) [repeat until 0 rows]
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL;
-- stage contract_schema (contract)
ALTER TABLE account_user DROP COLUMN note;
