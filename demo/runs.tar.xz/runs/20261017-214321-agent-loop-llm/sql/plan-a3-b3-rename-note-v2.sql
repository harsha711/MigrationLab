-- stage expand_1 (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
-- stage backfill_1 (backfill)
UPDATE account_user SET customer_note = note WHERE customer_note IS NULL;
-- stage sync_trigger_1 (expand)
CREATE OR REPLACE FUNCTION sync_note_customer_note() RETURNS trigger AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.note IS NOT NULL AND NEW.customer_note IS NULL THEN
      NEW.customer_note := NEW.note;
    ELSIF NEW.customer_note IS NOT NULL AND NEW.note IS NULL THEN
      NEW.note := NEW.customer_note;
    END IF;
  ELSIF TG_OP = 'UPDATE' THEN
    IF NEW.note IS DISTINCT FROM OLD.note THEN
      NEW.customer_note := NEW.note;
    END IF;
    IF NEW.customer_note IS DISTINCT FROM OLD.customer_note THEN
      NEW.note := NEW.customer_note;
    END IF;
  END IF;
  RETURN NEW;
END
$$ LANGUAGE plpgsql;
CREATE TRIGGER sync_note_customer_note_trig BEFORE INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_note_customer_note();
-- stage contract_1 (contract)
DROP TRIGGER sync_note_customer_note_trig ON account_user;
ALTER TABLE account_user DROP COLUMN note;
