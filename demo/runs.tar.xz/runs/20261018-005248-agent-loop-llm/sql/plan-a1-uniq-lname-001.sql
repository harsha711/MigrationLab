-- stage add_partial_unique_index (expand)
CREATE UNIQUE INDEX account_user_last_name_uniq_idx ON account_user (last_name) WHERE last_name IS NOT NULL;
