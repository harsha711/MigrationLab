-- stage expand_add_column_and_backfill (expand)
ALTER TABLE account_user ADD COLUMN customer_note TEXT;
UPDATE account_user SET customer_note = note;
-- stage expand_create_trigger (expand)
CREATE OR REPLACE FUNCTION sync_user_note_customer_note() RETURNS TRIGGER AS $$
BEGIN
   IF TG_OP = 'INSERT' THEN
      IF NEW.note IS DISTINCT FROM COALESCE(OLD.note, '') THEN
         NEW.customer_note := NEW.note;
      END IF;
      IF NEW.customer_note IS DISTINCT FROM COALESCE(OLD.customer_note, '') THEN
         NEW.note := NEW.customer_note;
      END IF;
   ELSIF TG_OP = 'UPDATE' THEN
      IF NEW.note IS DISTINCT FROM COALESCE(OLD.note, '') THEN
         NEW.customer_note := NEW.note;
      END IF;
      IF NEW.customer_note IS DISTINCT FROM COALESCE(OLD.customer_note, '') THEN
         NEW.note := NEW.customer_note;
      END IF;
   END IF;
   RETURN NEW;
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER sync_user_note_trig BEFORE INSERT OR UPDATE ON account_user FOR EACH ROW EXECUTE FUNCTION sync_user_note_customer_note();
-- stage contract_drop (contract)
ALTER TABLE account_user DROP COLUMN note;
