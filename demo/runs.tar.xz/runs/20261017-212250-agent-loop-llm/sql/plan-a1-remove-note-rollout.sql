-- stage expand_noop (expand)
SELECT 1;
-- stage contract_drop_note (contract)
ALTER TABLE account_user DROP COLUMN note;
