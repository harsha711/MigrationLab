-- stage expand_column (expand)
ALTER TABLE account_user ADD COLUMN IF NOT EXISTS customer_note TEXT NULL;
-- stage backfill_note (backfill) [repeat until 0 rows]
UPDATE account_user SET customer_note = note WHERE note IS NOT NULL AND customer_note IS NULL;
-- stage contract_column (contract)
ALTER TABLE account_user DROP COLUMN note;
